import requests
import json
from datetime import datetime

def lambda_handler(event, context):
    ultimo_sismo = obtener_ultimo_sismo_japon()

    if ultimo_sismo:
        return {
            'statusCode': 200,
            'body': json.dumps(ultimo_sismo)
        }
    else:
        return {
            'statusCode': 500,
            'body': 'Error al obtener los datos del último sismo en Japón'
        }

def obtener_ultimo_sismo_japon():
    url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        sismos = data["features"]

        ultimo_sismo = None
        for sismo in sismos:
            properties = sismo["properties"]
            lugar = properties["place"]
            magnitud = properties["mag"]
            fecha_hora = properties["time"]
            coordenadas = sismo["geometry"]["coordinates"]
            latitud = coordenadas[1]
            longitud = coordenadas[0]

            if "Japan" in lugar:
                sismo_info = {
                    "Lugar": lugar,
                    "Magnitud": magnitud,
                    "Fecha": obtener_fecha(fecha_hora),
                    "Hora": obtener_hora(fecha_hora),
                    "Latitud": latitud,
                    "Longitud": longitud
                }

                if ultimo_sismo is None or fecha_hora > ultimo_sismo["FechaHora"]:
                    ultimo_sismo = sismo_info

        return ultimo_sismo

    else:
        return None

def obtener_fecha(fecha_hora):
    # Convertir el tiempo UNIX en una cadena de fecha en formato legible
    fecha = datetime.utcfromtimestamp(fecha_hora / 1000).strftime("%Y-%m-%d")
    return fecha

def obtener_hora(fecha_hora):
    # Convertir el tiempo UNIX en una cadena de hora en formato legible
    hora = datetime.utcfromtimestamp(fecha_hora / 1000).strftime("%H:%M:%S")
    return hora
